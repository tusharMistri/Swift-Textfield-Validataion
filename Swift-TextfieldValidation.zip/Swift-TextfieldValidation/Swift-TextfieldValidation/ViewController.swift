
import UIKit

class ViewController: UIViewController {

    //MARK:- Outlets
    
    let set = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ ")

    @IBOutlet var textfield_number: UITextField!
    @IBOutlet var textfield_Name: UITextField!
    @IBOutlet var textfield_address: UITextField!
    @IBOutlet var textfield_password: UITextField!
    
    //MARK:- Variable Declration
    
    //MARK:- View LifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK:- Void Methods

    func checkValidNameorNot(strValue : String) -> Bool
    {
         var isValidName = Bool()
        let RegEx = "^[a-zA-Z]{1,10}$"
        let Test = NSPredicate(format:"SELF MATCHES %@", RegEx)
        isValidName =  Test.evaluate(with: strValue)
        return isValidName
    }
    
    func checkValidNumberorNot(strValue : String) -> Bool
    {
        // input should be like as '7891234560'  or '7894567891'
        let mobileNumberPattern = "[789][0-9]{9}"
        let mobileNumberPred = NSPredicate(format: "SELF MATCHES %@", mobileNumberPattern)
        let matched: Bool = mobileNumberPred.evaluate(with: strValue)
        return matched
    }
    
    func isValidEmailAddress(strValue: String) -> Bool
    {
        // input should be like as abc@gmail.com / abc@yahoo.in
        let stricterFilterString = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        
        let mobileNumberPred = NSPredicate(format: "SELF MATCHES %@", stricterFilterString)
        let matched: Bool = mobileNumberPred.evaluate(with: strValue)
        return matched
    }
    
    func isValidPaasword(strValue: String) -> Bool {
        /*
         // "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$" --> (Minimum 8 characters at least 1 Alphabet and 1 Number)
         // "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,16}$" --> (Minimum 8 and Maximum 16 characters at least 1 Alphabet, 1 Number and 1 Special Character)
         // "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$" --> (Minimum 8 characters at least 1 Uppercase Alphabet, 1 Lowercase Alphabet and 1 Number)
         // "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,}" --> (Minimum 8 characters at least 1 Uppercase Alphabet, 1 Lowercase Alphabet, 1 Number and 1 Special Character)
         // "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,10}" --> (Minimum 8 and Maximum 10 characters at least 1 Uppercase Alphabet, 1 Lowercase Alphabet, 1 Number and 1 Special Character)
         */
        let stricterFilterString = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"
        
        let mobileNumberPred = NSPredicate(format: "SELF MATCHES %@", stricterFilterString)
        let matched: Bool = mobileNumberPred.evaluate(with: strValue)
        return matched
    }

    
    func showAlertView(strAlertMessage: String) -> Void
    {
        let alert = UIAlertController.init(title: "APP Name", message: strAlertMessage, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    //MARK:- Button Action methods
    
    @IBAction func buttonClick_Submit(_ sender: UIButton)
    {
       
        let isValidName = self.checkValidNameorNot(strValue: textfield_Name.text!)
        
        let isValidEmail = self.isValidEmailAddress(strValue: textfield_address.text!)

        let isValidContact = self.checkValidNumberorNot(strValue: textfield_number.text!)

        let isValidaPassword = self.isValidPaasword(strValue: textfield_password.text!)

        
        if textfield_Name.text == nil || textfield_Name.text == "" {
            self.showAlertView(strAlertMessage: "Please enter valid name")
        }
        else if !isValidName
        {
            self.showAlertView(strAlertMessage: "Please enter valid name")
        }
        else if textfield_address.text == nil || textfield_address.text == ""
        {
            self.showAlertView(strAlertMessage: "Please enter valid email")
        }
        else if !isValidEmail
        {
            self.showAlertView(strAlertMessage: "Please enter valid email")
        }
        else if textfield_number.text == nil || textfield_number.text == "" {
            self.showAlertView(strAlertMessage: "Please enter valid number")
        }
        else if !isValidContact
        {
            self.showAlertView(strAlertMessage: "Please enter valid number")
        }
        else if textfield_password.text == nil || textfield_password.text == ""
        {
            self.showAlertView(strAlertMessage: "Please enter valid password")
        }
        else if !isValidaPassword
        {
            self.showAlertView(strAlertMessage: "Please enter valid password")
        }

        else
        {
            print("Success")
            // write your logic 
        }

    }
    
    //MARK:- Extra methods
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

